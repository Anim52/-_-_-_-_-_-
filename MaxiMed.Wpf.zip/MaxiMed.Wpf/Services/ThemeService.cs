﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MaxiMed.Wpf.Services
{
    public static class ThemeService
    {
        public static void SetTheme(bool dark)
        {
            var app = System.Windows.Application.Current;

            // найдём текущий словарь темы Light/Dark
            var existing = app.Resources.MergedDictionaries
                .FirstOrDefault(d => d.Source != null &&
                    (d.Source.OriginalString.Contains("Theme.Light.xaml") ||
                     d.Source.OriginalString.Contains("Theme.Dark.xaml")));

            if (existing != null)
                app.Resources.MergedDictionaries.Remove(existing);

            var newDict = new ResourceDictionary
            {
                Source = new Uri(dark ? "Themes/Theme.Dark.xaml" : "Themes/Theme.Light.xaml",
                                 UriKind.Relative)
            };

            app.Resources.MergedDictionaries.Insert(1, newDict);
        }

        public static void SetAccent(string accentFile) 
        {
            var app = System.Windows.Application.Current;

            var existing = app.Resources.MergedDictionaries
                .FirstOrDefault(d => d.Source != null && d.Source.OriginalString.Contains("Theme.Accent."));

            if (existing != null)
                app.Resources.MergedDictionaries.Remove(existing);

            app.Resources.MergedDictionaries.Insert(0, new ResourceDictionary
            {
                Source = new Uri(accentFile, UriKind.Relative)
            });
        }
    }
}
