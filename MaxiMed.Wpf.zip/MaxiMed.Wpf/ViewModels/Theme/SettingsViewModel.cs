﻿using CommunityToolkit.Mvvm.ComponentModel;
using MaxiMed.Wpf.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxiMed.Wpf.ViewModels.Theme
{
    public sealed partial class SettingsViewModel : ObservableObject
    {
        [ObservableProperty]
        private bool isDarkTheme;

        [ObservableProperty]
        private bool animationsEnabled = true;

        public ObservableCollection<string> Accents { get; } =
            new() { "Blue", "Green", "Purple" };

        [ObservableProperty]
        private string selectedAccent = "Blue";

        partial void OnIsDarkThemeChanged(bool value)
            => ThemeService.SetTheme(value);

        partial void OnSelectedAccentChanged(string value)
            => ThemeService.SetAccent($"Themes/Theme.Accent.{value}.xaml");
    }
}
